
(function() {
    const data = {"transcripts":[{"name":"captions","cues":[{"start":352,"text":"Close, if a word has a short"},{"start":2624,"text":"vowel phoneme and it ends in a"},{"start":4768,"text":"jeh then we are going to spell that last word with trigraph"},{"start":9408,"text":"dge"}]}]};
    window.globalLoadJsAsset('story_content/6fWYQiZ6hiZ_transcripts.js', JSON.stringify(data));
})();