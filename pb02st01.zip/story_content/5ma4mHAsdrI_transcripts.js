
(function() {
    const data = {"transcripts":[{"name":"captions","cues":[{"start":512,"text":"Lets play a game to find words with the short"},{"start":3584,"text":"e sound eh like in edge"}]}]};
    window.globalLoadJsAsset('story_content/5ma4mHAsdrI_transcripts.js', JSON.stringify(data));
})();