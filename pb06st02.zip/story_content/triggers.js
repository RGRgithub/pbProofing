function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5haaNQkrGHE":
        Script1();
        break;
      case "6fGGerRDm6R":
        Script2();
        break;
      case "6NJgMPuqCVS":
        Script3();
        break;
      case "5sMnvsv29SO":
        Script4();
        break;
      case "6ms1hw0I5Pk":
        Script5();
        break;
      case "5m6NLUy0THT":
        Script6();
        break;
      case "5YfsWpRlPq7":
        Script7();
        break;
      case "6Op2Bzwfn4j":
        Script8();
        break;
      case "5fHCJFQrbwf":
        Script9();
        break;
      case "5W14xVI9V9l":
        Script10();
        break;
      case "5zygepW1stb":
        Script11();
        break;
      case "6bPLYFHJNAc":
        Script12();
        break;
      case "5bL7PSCS5ne":
        Script13();
        break;
      case "5Zj4p5NLPoU":
        Script14();
        break;
      case "67xkc28dVyi":
        Script15();
        break;
      case "5leiw4Vauop":
        Script16();
        break;
      case "6cCLJG08w37":
        Script17();
        break;
      case "6P944rTQUoS":
        Script18();
        break;
      case "6DkHASunflq":
        Script19();
        break;
      case "65ZkfjyhPjL":
        Script20();
        break;
      case "6TxcOX5iwMu":
        Script21();
        break;
      case "6bamXPBvKKl":
        Script22();
        break;
      case "6SlPwEeyKjT":
        Script23();
        break;
      case "5hkP6lc5Ilj":
        Script24();
        break;
      case "6oqnRflYcYz":
        Script25();
        break;
      case "6SKBtxPeCib":
        Script26();
        break;
      case "5hpRicYl0Ci":
        Script27();
        break;
      case "6fC2i1YahBc":
        Script28();
        break;
      case "5t88ZS21MEc":
        Script29();
        break;
      case "6WBQ9S4LEhu":
        Script30();
        break;
      case "5WrOZufnhcY":
        Script31();
        break;
      case "5m4diVkpxRa":
        Script32();
        break;
      case "6FzKlu6hbt5":
        Script33();
        break;
      case "6FEntz2wB2A":
        Script34();
        break;
      case "69nKcJ9XewT":
        Script35();
        break;
      case "6Fpwcuyw6Xk":
        Script36();
        break;
      case "69lgBu2mDLa":
        Script37();
        break;
      case "5hym9Bjvdpg":
        Script38();
        break;
      case "6E1owkNBPSI":
        Script39();
        break;
      case "5qmZYj1uusa":
        Script40();
        break;
      case "6CQEb5kY137":
        Script41();
        break;
      case "5rGnEX6ndtq":
        Script42();
        break;
      case "5xycIvIbvWk":
        Script43();
        break;
      case "5d54GrO1R6c":
        Script44();
        break;
      case "6qiMT0NAjPP":
        Script45();
        break;
      case "5exYWJgs8H2":
        Script46();
        break;
      case "5n0q89QMIOI":
        Script47();
        break;
      case "64XUbaK8rJY":
        Script48();
        break;
      case "6gyTBGigRay":
        Script49();
        break;
      case "6l4DXeFdUOz":
        Script50();
        break;
      case "6pLXBwLdNeM":
        Script51();
        break;
      case "5lep4p4zlAl":
        Script52();
        break;
      case "5yj0nQV2vJ7":
        Script53();
        break;
      case "6JCGTsm78FZ":
        Script54();
        break;
      case "6Ue9dQEjnIp":
        Script55();
        break;
      case "6hc6hQPYCPb":
        Script56();
        break;
      case "5WA01L19nhb":
        Script57();
        break;
      case "6qosAaG2Zy0":
        Script58();
        break;
      case "6qksCFw1396":
        Script59();
        break;
      case "6bfGpTbjN1O":
        Script60();
        break;
      case "6r6YpQx7OtF":
        Script61();
        break;
      case "5yNheGHDYqf":
        Script62();
        break;
      case "5jokDZEHJTl":
        Script63();
        break;
      case "5aRuRkmRHcV":
        Script64();
        break;
      case "6q7bF00FBV8":
        Script65();
        break;
      case "5p6wrld1ZPt":
        Script66();
        break;
      case "6WjZLSHpJxP":
        Script67();
        break;
      case "63RXo0qq1J1":
        Script68();
        break;
      case "6egVpHsutsJ":
        Script69();
        break;
      case "6dXhlO2iuZI":
        Script70();
        break;
      case "63dY3EOdNdc":
        Script71();
        break;
      case "5VoT29M5b7f":
        Script72();
        break;
      case "6J5DQoK8FEF":
        Script73();
        break;
      case "6RrQUiBVvjp":
        Script74();
        break;
      case "5c22fTnfRHk":
        Script75();
        break;
      case "5qDT4X8mJwE":
        Script76();
        break;
      case "5gomN8yr5jk":
        Script77();
        break;
      case "6m6zvjOtQqs":
        Script78();
        break;
      case "6WYhduCIMEX":
        Script79();
        break;
      case "5sU8gqyETNm":
        Script80();
        break;
      case "6h0OSJrxOQa":
        Script81();
        break;
      case "6IATMTeQyWG":
        Script82();
        break;
      case "5iXNf63ra1y":
        Script83();
        break;
      case "5kvquU2sOa3":
        Script84();
        break;
      case "6SyfBif4opA":
        Script85();
        break;
      case "65H5ZGy9hIM":
        Script86();
        break;
      case "68A4fnGddSa":
        Script87();
        break;
      case "5YV5jI7p3EP":
        Script88();
        break;
      case "6cSLy0eh8Kt":
        Script89();
        break;
      case "5byV1LDE2uB":
        Script90();
        break;
      case "63auZfYWcOC":
        Script91();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
window.Script1 = function()
{
  player.once(() => {
const target = object('5jpuz9V0eut');
const duration = 1500;
const easing = 'ease-out';
const id = '6dXzT1rQWbt';
const pulseAmount = 0.07;
const delay = 39000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script2 = function()
{
  player.once(() => {
const target = object('5yUMrsQwya4');
const duration = 750;
const easing = 'ease-out';
const id = '6Tm0O4QxupM';
const pulseAmount = 0.07;
const delay = 76000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script3 = function()
{
  player.once(() => {
const target = object('5aOLdmDcHBh');
const duration = 750;
const easing = 'ease-out';
const id = '64qqqzaGhg4';
const pulseAmount = 0.07;
const delay = 81000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script4 = function()
{
  player.once(() => {
const target = object('6CMZLOgnEPs');
const duration = 750;
const easing = 'ease-out';
const id = '6mC3fepex8M';
const pulseAmount = 0.07;
const delay = 85000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script5 = function()
{
  player.once(() => {
const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 108000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script6 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script7 = function()
{
  player.once(() => {
const target = object('612AmuW8HrE');
const duration = 1500;
const easing = 'ease-out';
const id = '6J2frrhpfOf';
const pulseAmount = 0.07;
const delay = 112000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script8 = function()
{
  player.once(() => {
const target = object('6GaRnMfcvNB');
const duration = 2000;
const easing = 'ease-out';
const id = '6XoypW8FIyl';
const pulseAmount = 0.07;
const delay = 119250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script9 = function()
{
  player.once(() => {
const target = object('6MHj7FdyhGV');
const duration = 1500;
const easing = 'ease-out';
const id = '5t2XwWG7Sup';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script10 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script11 = function()
{
  const target = object('5mn4o9MTjTy');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script12 = function()
{
  const target = object('6GvUJYwV5Ik');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script13 = function()
{
  const target = object('5dVGn2xmJLX');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script14 = function()
{
  player.once(() => {
const target = object('5WSlUXHc5eC');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script15 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script16 = function()
{
  player.once(() => {
const target = object('67wwYmfaUIC');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 9458;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script17 = function()
{
  player.once(() => {
const target = object('5YriBLHF1fi');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 9458;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script18 = function()
{
  player.once(() => {
const target = object('5zdcqNqWbI1');
const duration = 1500;
const easing = 'ease-out';
const id = '61HuSZSRE9g';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script19 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script20 = function()
{
  const target = object('5vY5bfvRaMq');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script21 = function()
{
  player.once(() => {
const target = object('5tI9djaDgyI');
const duration = 750;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script22 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script23 = function()
{
  player.once(() => {
const target = object('6lb7uUBvwkF');
const duration = 750;
const easing = 'ease-out';
const id = '6GPtK9YZLpx';
const pulseAmount = 0.07;
const delay = 18000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script24 = function()
{
  player.once(() => {
const target = object('5mBMOghnR2Y');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 18000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script25 = function()
{
  player.once(() => {
const target = object('5nkgHR4pwAX');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script26 = function()
{
  player.once(() => {
const target = object('5rOza2qRZKX');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script27 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script28 = function()
{
  const target = object('5vPlgC0AGV1');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script29 = function()
{
  const target = object('5qY5vwAWuIe');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script30 = function()
{
  const target = object('5rOza2qRZKX');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script31 = function()
{
  player.once(() => {
const target = object('6iJnB6Uni16');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script32 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script33 = function()
{
  player.once(() => {
const target = object('6kHdCmk5us9');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 8771;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script34 = function()
{
  player.once(() => {
const target = object('6ZncsDaD43B');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 8771;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script35 = function()
{
  player.once(() => {
const target = object('6i17k43pT4C');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script36 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script37 = function()
{
  const target = object('6i17k43pT4C');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script38 = function()
{
  player.once(() => {
const target = object('6bLCw6aAMkL');
const duration = 1250;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script39 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script40 = function()
{
  player.once(() => {
const target = object('5bp0trzm1xF');
const duration = 750;
const easing = 'ease-out';
const id = '6GPtK9YZLpx';
const pulseAmount = 0.07;
const delay = 32500;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script41 = function()
{
  player.once(() => {
const target = object('5rGElrxsMrA');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 32500;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script42 = function()
{
  player.once(() => {
const target = object('6o2UIBBk1MT');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script43 = function()
{
  player.once(() => {
const target = object('6D7N9ivrEjv');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script44 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script45 = function()
{
  const target = object('5ZptlL8dg2O');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script46 = function()
{
  const target = object('6XKvL9sMu4u');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script47 = function()
{
  const target = object('6D7N9ivrEjv');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script48 = function()
{
  player.once(() => {
const target = object('6WcORRrIUCE');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script49 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script50 = function()
{
  player.once(() => {
const target = object('5i0VB3ZKJtI');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 7500;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script51 = function()
{
  player.once(() => {
const target = object('6qwxFiOECT3');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 7500;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script52 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script53 = function()
{
  const target = object('6cx0YN6AkgS');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script54 = function()
{
  player.once(() => {
const target = object('6AGg0MaqIzb');
const duration = 750;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script55 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script56 = function()
{
  player.once(() => {
const target = object('6B0gEtFYuQZ');
const duration = 750;
const easing = 'ease-out';
const id = '6GPtK9YZLpx';
const pulseAmount = 0.07;
const delay = 31500;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script57 = function()
{
  player.once(() => {
const target = object('6jh8Uxkjqsm');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 31500;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script58 = function()
{
  player.once(() => {
const target = object('6bkgZ5iqYn4');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script59 = function()
{
  player.once(() => {
const target = object('6aj1gojQYCO');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script60 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script61 = function()
{
  const target = object('6LAa4FcPBgM');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script62 = function()
{
  const target = object('5zKj5neZu5a');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script63 = function()
{
  const target = object('6aj1gojQYCO');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script64 = function()
{
  player.once(() => {
const target = object('6V3lg47BoB4');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script65 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script66 = function()
{
  player.once(() => {
const target = object('5zS3Hz2X5ps');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 9250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script67 = function()
{
  player.once(() => {
const target = object('5e1MmTLQ3vD');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 9250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script68 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script69 = function()
{
  const target = object('6huGCVuryCd');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script70 = function()
{
  player.once(() => {
const target = object('6a9P9WTzEii');
const duration = 750;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script71 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script72 = function()
{
  player.once(() => {
const target = object('6J7TvXZptO1');
const duration = 750;
const easing = 'ease-out';
const id = '6GPtK9YZLpx';
const pulseAmount = 0.07;
const delay = 29750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script73 = function()
{
  player.once(() => {
const target = object('5YUPDgi2W8i');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 29750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script74 = function()
{
  player.once(() => {
const target = object('5Yjtjo085Db');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script75 = function()
{
  player.once(() => {
const target = object('64B7E5njLVZ');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script76 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script77 = function()
{
  const target = object('6Bd0XeQKLuw');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script78 = function()
{
  const target = object('6YjQFEBD2fe');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script79 = function()
{
  const target = object('64B7E5njLVZ');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script80 = function()
{
  player.once(() => {
const target = object('5Yp3cVVXtqB');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script81 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script82 = function()
{
  player.once(() => {
const target = object('624N1sYtpe7');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 7250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script83 = function()
{
  player.once(() => {
const target = object('5wMZhjTbNed');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 7250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script84 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script85 = function()
{
  const target = object('6YtcvhMWYs8');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script86 = function()
{
  player.once(() => {
const target = object('5z3FPSoiqXD');
const duration = 750;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script87 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script88 = function()
{
  player.once(() => {
const target = object('60ak6f8rw94');
const duration = 750;
const easing = 'ease-out';
const id = '6GPtK9YZLpx';
const pulseAmount = 0.07;
const delay = 26875;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script89 = function()
{
  player.once(() => {
const target = object('5sEmw8bCArL');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 26875;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script90 = function()
{
  player.once(() => {
const target = object('6XgeS6RjmMG');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

};
