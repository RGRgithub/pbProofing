function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6U0GeWcMcoN":
        Script1();
        break;
      case "6AXQHGxq4nw":
        Script2();
        break;
      case "60MRH1V0Blz":
        Script3();
        break;
      case "5yhB72tUr5z":
        Script4();
        break;
      case "6YhBiq1aiAy":
        Script5();
        break;
      case "6G5cmjcXFVZ":
        Script6();
        break;
      case "6ERexv19Kzo":
        Script7();
        break;
      case "5x2dVXCfTWl":
        Script8();
        break;
      case "6KCAHab0QGK":
        Script9();
        break;
      case "608SRBNAG0U":
        Script10();
        break;
      case "5exASRo8Hpw":
        Script11();
        break;
      case "64MLR21twOV":
        Script12();
        break;
      case "6VTxKR8xmo8":
        Script13();
        break;
      case "6PTKzGUyQ8W":
        Script14();
        break;
      case "5xjDKp9EF1V":
        Script15();
        break;
      case "6GGlcZWRLoE":
        Script16();
        break;
      case "6ATMAeFLXsj":
        Script17();
        break;
      case "5X4E0vlrwMQ":
        Script18();
        break;
      case "6qEthfwB14g":
        Script19();
        break;
      case "5glv7c5Rw1z":
        Script20();
        break;
      case "5aRuLm5jC2K":
        Script21();
        break;
      case "6MSyS8JCmiZ":
        Script22();
        break;
      case "6kfnrvDMkX4":
        Script23();
        break;
      case "67AHxLfAsMz":
        Script24();
        break;
      case "5pOUwPMNlhy":
        Script25();
        break;
      case "6A6aze519bu":
        Script26();
        break;
      case "6rilijr2fis":
        Script27();
        break;
      case "5k3iKQfnE1y":
        Script28();
        break;
      case "6JSOfAiZjPp":
        Script29();
        break;
      case "5kTjrEJ1AuX":
        Script30();
        break;
      case "6PkGDBVrf85":
        Script31();
        break;
      case "6VNt38GLSZ6":
        Script32();
        break;
      case "6r6IMpKZShI":
        Script33();
        break;
      case "5yUIVG3ujg2":
        Script34();
        break;
      case "5wYFxJq29rq":
        Script35();
        break;
      case "6XOa8EgrM9q":
        Script36();
        break;
      case "69Gxa3LZYUw":
        Script37();
        break;
      case "6U9A4V7qzWa":
        Script38();
        break;
      case "5ug6dVBaDB7":
        Script39();
        break;
      case "5qRTnSN8KrC":
        Script40();
        break;
      case "5Ymw1vbrrBW":
        Script41();
        break;
      case "5ubWzU5JgJY":
        Script42();
        break;
      case "5icR3jf1W5w":
        Script43();
        break;
      case "5lokv3EWiVL":
        Script44();
        break;
      case "6nJBCg4KIGb":
        Script45();
        break;
      case "6g3YXUqX5py":
        Script46();
        break;
      case "6B2QfD7gY5l":
        Script47();
        break;
      case "64sVxXhtVzv":
        Script48();
        break;
      case "5zBxebggyzA":
        Script49();
        break;
      case "6HL28gMzGJD":
        Script50();
        break;
      case "5wsM7ghoVcw":
        Script51();
        break;
      case "5ecXkNXtzt1":
        Script52();
        break;
      case "5mbiYyQXFcb":
        Script53();
        break;
      case "60x6QwwO8QQ":
        Script54();
        break;
      case "6T3VOzZPk88":
        Script55();
        break;
      case "6cBFSlvn2HX":
        Script56();
        break;
      case "6mFhkGjC6bA":
        Script57();
        break;
      case "5f0vf1ctolj":
        Script58();
        break;
      case "5th2V6ZtvmO":
        Script59();
        break;
      case "68piNM4v2Aq":
        Script60();
        break;
      case "6FL7esi1dcL":
        Script61();
        break;
      case "5mmrXQnDwOk":
        Script62();
        break;
      case "6RWnvNn2FOb":
        Script63();
        break;
      case "6PJv3NJ7vFp":
        Script64();
        break;
      case "5qoe8FLhBuy":
        Script65();
        break;
      case "5YEBGwi4iMJ":
        Script66();
        break;
      case "5kyU4IwLV2Z":
        Script67();
        break;
      case "66sslBxgnSj":
        Script68();
        break;
      case "6h60aAtm0El":
        Script69();
        break;
      case "69Ht2MytAap":
        Script70();
        break;
      case "6JhDWC75cP6":
        Script71();
        break;
      case "67eqLNczjZr":
        Script72();
        break;
      case "5r76sbkq7J7":
        Script73();
        break;
      case "6cDD5FUoTil":
        Script74();
        break;
      case "6kjAKAQfTV6":
        Script75();
        break;
      case "6GSmCGqfAXe":
        Script76();
        break;
      case "6cgwZPMdYvo":
        Script77();
        break;
      case "6EceMHr83SG":
        Script78();
        break;
      case "66McgHHPkZ1":
        Script79();
        break;
      case "6n5WxIhD3ut":
        Script80();
        break;
      case "6mpFpY34mJE":
        Script81();
        break;
      case "6ftpDcbLuC2":
        Script82();
        break;
      case "6GmxWhlYmqy":
        Script83();
        break;
      case "69XRLEEXwIt":
        Script84();
        break;
      case "6E7HbqJegAs":
        Script85();
        break;
      case "6d3QOL2bfKv":
        Script86();
        break;
      case "6awVdvFZaht":
        Script87();
        break;
      case "5YOL6br34Oh":
        Script88();
        break;
      case "6UzE9RnbuC8":
        Script89();
        break;
      case "6H9waDgT8GJ":
        Script90();
        break;
      case "6KNSnpWO8o7":
        Script91();
        break;
      case "6KVh0mXI7uv":
        Script92();
        break;
      case "6RhrKsgWeLR":
        Script93();
        break;
      case "6qXvYYG2DzG":
        Script94();
        break;
      case "6g64WPP4Fob":
        Script95();
        break;
      case "6iT4DXhhQ0O":
        Script96();
        break;
      case "5UmxUTUcYKn":
        Script97();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
window.Script1 = function()
{
  player.once(() => {
const target = object('6YvyQvYDvrp');
const duration = 1500;
const easing = 'ease-out';
const id = '5k4Mli6EtWI';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script2 = function()
{
  player.once(() => {
const target = object('6YvyQvYDvrp');
const duration = 1500;
const easing = 'ease-out';
const id = '5k4Mli6EtWI';
const pulseAmount = 0.07;
const delay = 28000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script3 = function()
{
  player.once(() => {
const target = object('6IDRwPzv7x9');
const duration = 1500;
const easing = 'ease-out';
const id = '6JheYHIpH0o';
const pulseAmount = 0.1;
const delay = 62000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script4 = function()
{
  player.once(() => {
const target = object('65rT74EsCbr');
const duration = 1500;
const easing = 'ease-out';
const id = '5qmop5hE86h';
const pulseAmount = 0.1;
const delay = 68000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script5 = function()
{
  player.once(() => {
const target = object('5yuseDTr3tj');
const duration = 750;
const easing = 'ease-out';
const id = '6dXvbVLHGa9';
const pulseAmount = 0.07;
const delay = 74000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script6 = function()
{
  player.once(() => {
const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 86750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script7 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script8 = function()
{
  player.once(() => {
const target = object('612AmuW8HrE');
const duration = 1500;
const easing = 'ease-out';
const id = '6J2frrhpfOf';
const pulseAmount = 0.07;
const delay = 91500;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script9 = function()
{
  player.once(() => {
const target = object('6GaRnMfcvNB');
const duration = 2000;
const easing = 'ease-out';
const id = '6XoypW8FIyl';
const pulseAmount = 0.07;
const delay = 97146;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script10 = function()
{
  player.once(() => {
const target = object('6MHj7FdyhGV');
const duration = 1500;
const easing = 'ease-out';
const id = '5t2XwWG7Sup';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script11 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script12 = function()
{
  const target = object('5mn4o9MTjTy');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script13 = function()
{
  const target = object('6GvUJYwV5Ik');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script14 = function()
{
  const target = object('5dVGn2xmJLX');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script15 = function()
{
  player.once(() => {
const target = object('5WSlUXHc5eC');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script16 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script17 = function()
{
  player.once(() => {
const target = object('67wwYmfaUIC');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script18 = function()
{
  player.once(() => {
const target = object('5YriBLHF1fi');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script19 = function()
{
  player.once(() => {
const target = object('5zdcqNqWbI1');
const duration = 1500;
const easing = 'ease-out';
const id = '61HuSZSRE9g';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script20 = function()
{
  player.once(() => {
const target = object('5vY5bfvRaMq');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script21 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script22 = function()
{
  const target = object('5vY5bfvRaMq');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script23 = function()
{
  player.once(() => {
const target = object('5tI9djaDgyI');
const duration = 750;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script24 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script25 = function()
{
  player.once(() => {
const target = object('6lb7uUBvwkF');
const duration = 750;
const easing = 'ease-out';
const id = '6GPtK9YZLpx';
const pulseAmount = 0.07;
const delay = 26750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script26 = function()
{
  player.once(() => {
const target = object('5mBMOghnR2Y');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 26750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script27 = function()
{
  player.once(() => {
const target = object('5nkgHR4pwAX');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script28 = function()
{
  player.once(() => {
const target = object('5rOza2qRZKX');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script29 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script30 = function()
{
  const target = object('5vPlgC0AGV1');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script31 = function()
{
  const target = object('5qY5vwAWuIe');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script32 = function()
{
  const target = object('5rOza2qRZKX');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script33 = function()
{
  player.once(() => {
const target = object('6iJnB6Uni16');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script34 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script35 = function()
{
  player.once(() => {
const target = object('6kHdCmk5us9');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script36 = function()
{
  player.once(() => {
const target = object('6ZncsDaD43B');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script37 = function()
{
  player.once(() => {
const target = object('6i17k43pT4C');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script38 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script39 = function()
{
  const target = object('6i17k43pT4C');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script40 = function()
{
  player.once(() => {
const target = object('6bLCw6aAMkL');
const duration = 1250;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script41 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script42 = function()
{
  player.once(() => {
const target = object('5bp0trzm1xF');
const duration = 750;
const easing = 'ease-out';
const id = '6GPtK9YZLpx';
const pulseAmount = 0.07;
const delay = 24750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script43 = function()
{
  player.once(() => {
const target = object('5rGElrxsMrA');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 24750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script44 = function()
{
  player.once(() => {
const target = object('6o2UIBBk1MT');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script45 = function()
{
  player.once(() => {
const target = object('6D7N9ivrEjv');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script46 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script47 = function()
{
  const target = object('5ZptlL8dg2O');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script48 = function()
{
  const target = object('6XKvL9sMu4u');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script49 = function()
{
  const target = object('6D7N9ivrEjv');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script50 = function()
{
  player.once(() => {
const target = object('6WcORRrIUCE');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script51 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script52 = function()
{
  player.once(() => {
const target = object('5i0VB3ZKJtI');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script53 = function()
{
  player.once(() => {
const target = object('6qwxFiOECT3');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script54 = function()
{
  player.once(() => {
const target = object('6cx0YN6AkgS');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script55 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script56 = function()
{
  const target = object('6cx0YN6AkgS');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script57 = function()
{
  player.once(() => {
const target = object('6AGg0MaqIzb');
const duration = 750;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script58 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script59 = function()
{
  player.once(() => {
const target = object('6B0gEtFYuQZ');
const duration = 750;
const easing = 'ease-out';
const id = '6GPtK9YZLpx';
const pulseAmount = 0.07;
const delay = 30000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script60 = function()
{
  player.once(() => {
const target = object('6jh8Uxkjqsm');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 30000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script61 = function()
{
  player.once(() => {
const target = object('6bkgZ5iqYn4');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script62 = function()
{
  player.once(() => {
const target = object('6aj1gojQYCO');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script63 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script64 = function()
{
  const target = object('6LAa4FcPBgM');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script65 = function()
{
  const target = object('5zKj5neZu5a');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script66 = function()
{
  const target = object('6aj1gojQYCO');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script67 = function()
{
  player.once(() => {
const target = object('6V3lg47BoB4');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script68 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script69 = function()
{
  player.once(() => {
const target = object('5zS3Hz2X5ps');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script70 = function()
{
  player.once(() => {
const target = object('5e1MmTLQ3vD');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script71 = function()
{
  player.once(() => {
const target = object('6huGCVuryCd');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script72 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script73 = function()
{
  const target = object('6huGCVuryCd');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script74 = function()
{
  player.once(() => {
const target = object('6a9P9WTzEii');
const duration = 750;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script75 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script76 = function()
{
  player.once(() => {
const target = object('6J7TvXZptO1');
const duration = 750;
const easing = 'ease-out';
const id = '6GPtK9YZLpx';
const pulseAmount = 0.07;
const delay = 28750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script77 = function()
{
  player.once(() => {
const target = object('5YUPDgi2W8i');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 28750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script78 = function()
{
  player.once(() => {
const target = object('5Yjtjo085Db');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script79 = function()
{
  player.once(() => {
const target = object('64B7E5njLVZ');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script80 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script81 = function()
{
  const target = object('6Bd0XeQKLuw');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script82 = function()
{
  const target = object('6YjQFEBD2fe');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script83 = function()
{
  const target = object('64B7E5njLVZ');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script84 = function()
{
  player.once(() => {
const target = object('5Yp3cVVXtqB');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script85 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script86 = function()
{
  player.once(() => {
const target = object('624N1sYtpe7');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script87 = function()
{
  player.once(() => {
const target = object('5wMZhjTbNed');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script88 = function()
{
  player.once(() => {
const target = object('6YtcvhMWYs8');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script89 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script90 = function()
{
  const target = object('6YtcvhMWYs8');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script91 = function()
{
  player.once(() => {
const target = object('5z3FPSoiqXD');
const duration = 750;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script92 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script93 = function()
{
  player.once(() => {
const target = object('60ak6f8rw94');
const duration = 750;
const easing = 'ease-out';
const id = '6GPtK9YZLpx';
const pulseAmount = 0.07;
const delay = 26250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script94 = function()
{
  player.once(() => {
const target = object('5sEmw8bCArL');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 26250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script95 = function()
{
  player.once(() => {
const target = object('6XgeS6RjmMG');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

};
function getActor() {
  return {
    "mbox": "mailto:mark.snyder@reallygreatreading.com",
    "objectType": "Agent",
    "name": "Playbooks Example"
  };
}
