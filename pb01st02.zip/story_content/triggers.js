function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6nWyvPSIE1z":
        Script1();
        break;
      case "6dUwM7prnSg":
        Script2();
        break;
      case "5X180q7ZDt0":
        Script3();
        break;
      case "5smDWDa3pFd":
        Script4();
        break;
      case "5wH0K0QwqI7":
        Script5();
        break;
      case "6fevcP8rcSt":
        Script6();
        break;
      case "5rdCpBtK315":
        Script7();
        break;
      case "5UnKbyc7sEN":
        Script8();
        break;
      case "5gZpKcDl3km":
        Script9();
        break;
      case "5osn6iADyzM":
        Script10();
        break;
      case "6o1HP2dYk4A":
        Script11();
        break;
      case "62Hjx6VdCX0":
        Script12();
        break;
      case "5llazIcd1ED":
        Script13();
        break;
      case "6a0Gvl6fZTV":
        Script14();
        break;
      case "6Muw7Jlt1Py":
        Script15();
        break;
      case "6VQJZvb5WQF":
        Script16();
        break;
      case "5pRFVPyQkQw":
        Script17();
        break;
      case "5o9gJ4c4j3I":
        Script18();
        break;
      case "6pWOYUlvsMB":
        Script19();
        break;
      case "6HGDM7jGvdj":
        Script20();
        break;
      case "6BS1wPTH0Oj":
        Script21();
        break;
      case "6Q1vVEvLZxy":
        Script22();
        break;
      case "6GBh96vgCFz":
        Script23();
        break;
      case "5XeH0eIt8bV":
        Script24();
        break;
      case "6GStG6CtlSC":
        Script25();
        break;
      case "6ci0heyA1hI":
        Script26();
        break;
      case "60mR46Da13g":
        Script27();
        break;
      case "6EfLXDgLnFv":
        Script28();
        break;
      case "5uwfefGyPDi":
        Script29();
        break;
      case "6dhuiawJboQ":
        Script30();
        break;
      case "5ggFYfuErd3":
        Script31();
        break;
      case "66RjrovRuAg":
        Script32();
        break;
      case "616mjadh3Xr":
        Script33();
        break;
      case "5kZBtwDl4Sv":
        Script34();
        break;
      case "6elvWsLn7oo":
        Script35();
        break;
      case "5hgw5AhSHW5":
        Script36();
        break;
      case "6H7QijhshVy":
        Script37();
        break;
      case "5e1VzsWPom6":
        Script38();
        break;
      case "5g0ik5lPOHy":
        Script39();
        break;
      case "6AMrsbBeAVh":
        Script40();
        break;
      case "6qwj1A8EfIq":
        Script41();
        break;
      case "5Z8yB6iINbj":
        Script42();
        break;
      case "5zRctBBtbwo":
        Script43();
        break;
      case "6cA6RdiD7Ur":
        Script44();
        break;
      case "5VUzw3AbJnU":
        Script45();
        break;
      case "5gDrknVLThu":
        Script46();
        break;
      case "6iwMA8aSvG0":
        Script47();
        break;
      case "5t2Q3V1vHFP":
        Script48();
        break;
      case "5bWykwJwZws":
        Script49();
        break;
      case "6QcmFBeLMxW":
        Script50();
        break;
      case "6Q3vHX8LgIj":
        Script51();
        break;
      case "5jcAiPVEBxj":
        Script52();
        break;
      case "5w6L6v8QGYl":
        Script53();
        break;
      case "5WxHy50oHZj":
        Script54();
        break;
      case "5yLd9ysrM3c":
        Script55();
        break;
      case "5ZQcjx3awae":
        Script56();
        break;
      case "6OcZ5LDytz3":
        Script57();
        break;
      case "6pwEFrTQRRB":
        Script58();
        break;
      case "6oIHM7uQqod":
        Script59();
        break;
      case "61dpjhMlHXP":
        Script60();
        break;
      case "5VE9qP3SvmO":
        Script61();
        break;
      case "6kRmF0Ha7lZ":
        Script62();
        break;
      case "6AmOqqbiv56":
        Script63();
        break;
      case "68pV4sGKQIW":
        Script64();
        break;
      case "6CSmqH50Y0K":
        Script65();
        break;
      case "5kQn44WfGnl":
        Script66();
        break;
      case "5kbiYyk457v":
        Script67();
        break;
      case "6doh5kSGUAM":
        Script68();
        break;
      case "61EuHNhuXaq":
        Script69();
        break;
      case "6oivYHRAQsc":
        Script70();
        break;
      case "5XrTI2iDLM6":
        Script71();
        break;
      case "6ouDn5p9ee0":
        Script72();
        break;
      case "6O0n82MixM4":
        Script73();
        break;
      case "6UmL0QRncQ7":
        Script74();
        break;
      case "6m54hRuXr3C":
        Script75();
        break;
      case "5kfT1zeEcsM":
        Script76();
        break;
      case "6fgUMyXW1ed":
        Script77();
        break;
      case "6hNHLQVD4Jf":
        Script78();
        break;
      case "5cQ8qsYGtgY":
        Script79();
        break;
      case "6PNIU1HlYCi":
        Script80();
        break;
      case "61nvPA9mFHE":
        Script81();
        break;
      case "6RxBy6iOYj9":
        Script82();
        break;
      case "66jyHuLOmHX":
        Script83();
        break;
      case "5osCOTlBqA3":
        Script84();
        break;
      case "5a0BTlq8GaR":
        Script85();
        break;
      case "5ayxi89WJL3":
        Script86();
        break;
      case "6382uAoISL4":
        Script87();
        break;
      case "6ENU4eedczy":
        Script88();
        break;
      case "67WtpaN2ZGq":
        Script89();
        break;
      case "6FgyeziE7Jq":
        Script90();
        break;
      case "6SO9VNNeLoL":
        Script91();
        break;
      case "6evDniCj5pD":
        Script92();
        break;
      case "645tZTWVQC2":
        Script93();
        break;
      case "6iKezAssjdj":
        Script94();
        break;
      case "66eYJVaNIdA":
        Script95();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
window.Script1 = function()
{
  player.once(() => {
const target = object('6YvyQvYDvrp');
const duration = 1500;
const easing = 'ease-out';
const id = '5k4Mli6EtWI';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script2 = function()
{
  player.once(() => {
const target = object('6YvyQvYDvrp');
const duration = 1500;
const easing = 'ease-out';
const id = '5k4Mli6EtWI';
const pulseAmount = 0.07;
const delay = 28000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script3 = function()
{
  player.once(() => {
const target = object('6IDRwPzv7x9');
const duration = 1500;
const easing = 'ease-out';
const id = '6JheYHIpH0o';
const pulseAmount = 0.1;
const delay = 62000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script4 = function()
{
  player.once(() => {
const target = object('65rT74EsCbr');
const duration = 1500;
const easing = 'ease-out';
const id = '5qmop5hE86h';
const pulseAmount = 0.1;
const delay = 68000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script5 = function()
{
  player.once(() => {
const target = object('5yuseDTr3tj');
const duration = 750;
const easing = 'ease-out';
const id = '6dXvbVLHGa9';
const pulseAmount = 0.07;
const delay = 74000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script6 = function()
{
  player.once(() => {
const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 86750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script7 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script8 = function()
{
  player.once(() => {
const target = object('612AmuW8HrE');
const duration = 1500;
const easing = 'ease-out';
const id = '6J2frrhpfOf';
const pulseAmount = 0.07;
const delay = 91500;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script9 = function()
{
  player.once(() => {
const target = object('6GaRnMfcvNB');
const duration = 2000;
const easing = 'ease-out';
const id = '6XoypW8FIyl';
const pulseAmount = 0.07;
const delay = 97146;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script10 = function()
{
  player.once(() => {
const target = object('6MHj7FdyhGV');
const duration = 1500;
const easing = 'ease-out';
const id = '5t2XwWG7Sup';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script11 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script12 = function()
{
  const target = object('5mn4o9MTjTy');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script13 = function()
{
  const target = object('6GvUJYwV5Ik');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script14 = function()
{
  const target = object('5dVGn2xmJLX');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script15 = function()
{
  player.once(() => {
const target = object('5WSlUXHc5eC');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script16 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script17 = function()
{
  player.once(() => {
const target = object('67wwYmfaUIC');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script18 = function()
{
  player.once(() => {
const target = object('5YriBLHF1fi');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script19 = function()
{
  player.once(() => {
const target = object('5zdcqNqWbI1');
const duration = 1500;
const easing = 'ease-out';
const id = '61HuSZSRE9g';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script20 = function()
{
  player.once(() => {
const target = object('5vY5bfvRaMq');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script21 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script22 = function()
{
  const target = object('5vY5bfvRaMq');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script23 = function()
{
  player.once(() => {
const target = object('5tI9djaDgyI');
const duration = 750;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script24 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script25 = function()
{
  player.once(() => {
const target = object('5mBMOghnR2Y');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 26750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script26 = function()
{
  player.once(() => {
const target = object('5nkgHR4pwAX');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script27 = function()
{
  player.once(() => {
const target = object('5rOza2qRZKX');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script28 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script29 = function()
{
  const target = object('5vPlgC0AGV1');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script30 = function()
{
  const target = object('5qY5vwAWuIe');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script31 = function()
{
  const target = object('5rOza2qRZKX');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script32 = function()
{
  player.once(() => {
const target = object('6iJnB6Uni16');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script33 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script34 = function()
{
  player.once(() => {
const target = object('6kHdCmk5us9');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script35 = function()
{
  player.once(() => {
const target = object('6ZncsDaD43B');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script36 = function()
{
  player.once(() => {
const target = object('6i17k43pT4C');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script37 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script38 = function()
{
  const target = object('6i17k43pT4C');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script39 = function()
{
  player.once(() => {
const target = object('6bLCw6aAMkL');
const duration = 1250;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script40 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script41 = function()
{
  player.once(() => {
const target = object('5bp0trzm1xF');
const duration = 750;
const easing = 'ease-out';
const id = '6GPtK9YZLpx';
const pulseAmount = 0.07;
const delay = 24750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script42 = function()
{
  player.once(() => {
const target = object('5rGElrxsMrA');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 24750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script43 = function()
{
  player.once(() => {
const target = object('6o2UIBBk1MT');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script44 = function()
{
  player.once(() => {
const target = object('6D7N9ivrEjv');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script45 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script46 = function()
{
  const target = object('5ZptlL8dg2O');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script47 = function()
{
  const target = object('6XKvL9sMu4u');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script48 = function()
{
  const target = object('6D7N9ivrEjv');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script49 = function()
{
  player.once(() => {
const target = object('6WcORRrIUCE');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script50 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script51 = function()
{
  player.once(() => {
const target = object('5i0VB3ZKJtI');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script52 = function()
{
  player.once(() => {
const target = object('6qwxFiOECT3');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script53 = function()
{
  player.once(() => {
const target = object('6cx0YN6AkgS');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script54 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script55 = function()
{
  const target = object('6cx0YN6AkgS');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script56 = function()
{
  player.once(() => {
const target = object('6AGg0MaqIzb');
const duration = 750;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script57 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script58 = function()
{
  player.once(() => {
const target = object('6B0gEtFYuQZ');
const duration = 750;
const easing = 'ease-out';
const id = '6GPtK9YZLpx';
const pulseAmount = 0.07;
const delay = 30000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script59 = function()
{
  player.once(() => {
const target = object('6jh8Uxkjqsm');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 30000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script60 = function()
{
  player.once(() => {
const target = object('6bkgZ5iqYn4');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script61 = function()
{
  player.once(() => {
const target = object('6aj1gojQYCO');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script62 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script63 = function()
{
  const target = object('6LAa4FcPBgM');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script64 = function()
{
  const target = object('5zKj5neZu5a');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script65 = function()
{
  const target = object('6aj1gojQYCO');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script66 = function()
{
  player.once(() => {
const target = object('6V3lg47BoB4');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script67 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script68 = function()
{
  player.once(() => {
const target = object('5zS3Hz2X5ps');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script69 = function()
{
  player.once(() => {
const target = object('5e1MmTLQ3vD');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script70 = function()
{
  player.once(() => {
const target = object('6huGCVuryCd');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script71 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script72 = function()
{
  const target = object('6huGCVuryCd');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script73 = function()
{
  player.once(() => {
const target = object('6a9P9WTzEii');
const duration = 750;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script74 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script75 = function()
{
  player.once(() => {
const target = object('6J7TvXZptO1');
const duration = 750;
const easing = 'ease-out';
const id = '6GPtK9YZLpx';
const pulseAmount = 0.07;
const delay = 28750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script76 = function()
{
  player.once(() => {
const target = object('5YUPDgi2W8i');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 28750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script77 = function()
{
  player.once(() => {
const target = object('5Yjtjo085Db');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script78 = function()
{
  player.once(() => {
const target = object('64B7E5njLVZ');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script79 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script80 = function()
{
  const target = object('6Bd0XeQKLuw');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script81 = function()
{
  const target = object('6YjQFEBD2fe');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script82 = function()
{
  const target = object('64B7E5njLVZ');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script83 = function()
{
  player.once(() => {
const target = object('5Yp3cVVXtqB');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script84 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script85 = function()
{
  player.once(() => {
const target = object('624N1sYtpe7');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script86 = function()
{
  player.once(() => {
const target = object('5wMZhjTbNed');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script87 = function()
{
  player.once(() => {
const target = object('6YtcvhMWYs8');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script88 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script89 = function()
{
  const target = object('6YtcvhMWYs8');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script90 = function()
{
  player.once(() => {
const target = object('5z3FPSoiqXD');
const duration = 750;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script91 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script92 = function()
{
  player.once(() => {
const target = object('60ak6f8rw94');
const duration = 750;
const easing = 'ease-out';
const id = '6GPtK9YZLpx';
const pulseAmount = 0.07;
const delay = 26250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script93 = function()
{
  player.once(() => {
const target = object('5sEmw8bCArL');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 26250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script94 = function()
{
  player.once(() => {
const target = object('6XgeS6RjmMG');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

};
