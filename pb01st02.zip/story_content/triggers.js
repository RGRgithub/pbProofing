function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5z8DENJeuJZ":
        Script1();
        break;
      case "5qYf1PsyKfn":
        Script2();
        break;
      case "6CeHuWvivCN":
        Script3();
        break;
      case "6CeVOFlGYjz":
        Script4();
        break;
      case "5dFn5NosQdi":
        Script5();
        break;
      case "6h47pGQ1SX6":
        Script6();
        break;
      case "609PdOf8n7M":
        Script7();
        break;
      case "6UkunmRRknW":
        Script8();
        break;
      case "5xMIulNxkq2":
        Script9();
        break;
      case "6o6ETiWdiUt":
        Script10();
        break;
      case "5hoOdaxdJ8T":
        Script11();
        break;
      case "6AzPSG44KcM":
        Script12();
        break;
      case "671SIHX1ZAQ":
        Script13();
        break;
      case "6aquKiE5al0":
        Script14();
        break;
      case "6jXUxr1EG69":
        Script15();
        break;
      case "6qbLWYmOrb3":
        Script16();
        break;
      case "6NHizdqpKg9":
        Script17();
        break;
      case "5xXLL3tgI8e":
        Script18();
        break;
      case "65KwIdwKE1d":
        Script19();
        break;
      case "6AQ76NMpx6e":
        Script20();
        break;
      case "6jx8ew9lgOd":
        Script21();
        break;
      case "6Etx3U8thni":
        Script22();
        break;
      case "61Bijr5fxGm":
        Script23();
        break;
      case "6IKszFOMA1r":
        Script24();
        break;
      case "6h1w6ocw6eW":
        Script25();
        break;
      case "6dFF87O8GSS":
        Script26();
        break;
      case "5hqUt2x7pMl":
        Script27();
        break;
      case "6NNLd9fZao8":
        Script28();
        break;
      case "698kRVR2oeE":
        Script29();
        break;
      case "5gd4zbGncu6":
        Script30();
        break;
      case "5yeUHdSWGKH":
        Script31();
        break;
      case "6czdr55pW1d":
        Script32();
        break;
      case "6kqKVcm440e":
        Script33();
        break;
      case "5iyGbK6FTNr":
        Script34();
        break;
      case "66XHL8PASrN":
        Script35();
        break;
      case "6fpn9JwKXlP":
        Script36();
        break;
      case "5sR4i6u3D3v":
        Script37();
        break;
      case "6YagadH7sWr":
        Script38();
        break;
      case "6BYOjm2vAGX":
        Script39();
        break;
      case "5zkfU7xCfcn":
        Script40();
        break;
      case "5VklyXAEBj0":
        Script41();
        break;
      case "6oBwlLyeN3O":
        Script42();
        break;
      case "5hxqxzAUWSJ":
        Script43();
        break;
      case "6PLz8sE0HJX":
        Script44();
        break;
      case "5savJu3iP4n":
        Script45();
        break;
      case "5tRy4xEiick":
        Script46();
        break;
      case "5rpNhgAyvAT":
        Script47();
        break;
      case "6r9xMdcyFib":
        Script48();
        break;
      case "6X04XymBv1t":
        Script49();
        break;
      case "60R7DM6CtBI":
        Script50();
        break;
      case "6UNzS2qjS6O":
        Script51();
        break;
      case "5g58i7wkoFQ":
        Script52();
        break;
      case "5nY4Jc1IFq0":
        Script53();
        break;
      case "61Plgm9J0Eo":
        Script54();
        break;
      case "5YM0Lf2Ve8z":
        Script55();
        break;
      case "5tBrzVtZwnR":
        Script56();
        break;
      case "6QS8tAklfB7":
        Script57();
        break;
      case "6rpd5uR2sjl":
        Script58();
        break;
      case "6XBTQti83qn":
        Script59();
        break;
      case "5wpfZMYUYyX":
        Script60();
        break;
      case "5ozDX1eigka":
        Script61();
        break;
      case "648iIPjwpmJ":
        Script62();
        break;
      case "6KgyAxMwNj1":
        Script63();
        break;
      case "6azqieVzA07":
        Script64();
        break;
      case "5xzNaTzQfcd":
        Script65();
        break;
      case "5a7Jikgvy18":
        Script66();
        break;
      case "5zGFWdM7rAz":
        Script67();
        break;
      case "5dU52y0FfLQ":
        Script68();
        break;
      case "5gV37xTi8fd":
        Script69();
        break;
      case "5nP8oM1EShY":
        Script70();
        break;
      case "6LJEpE5KvY7":
        Script71();
        break;
      case "5yzb0d0E254":
        Script72();
        break;
      case "5zmJAV8n5t6":
        Script73();
        break;
      case "6Vjf7ZKAz6z":
        Script74();
        break;
      case "5cxgXZGtkJ5":
        Script75();
        break;
      case "5upsERQmKqX":
        Script76();
        break;
      case "6RdeX20qsYk":
        Script77();
        break;
      case "6Uq7S11mXmJ":
        Script78();
        break;
      case "5WclHP3L0J2":
        Script79();
        break;
      case "6kUHezMcyIi":
        Script80();
        break;
      case "6NeMk1NSyaU":
        Script81();
        break;
      case "5hOd7zyoAfA":
        Script82();
        break;
      case "6pgYOuHyiu8":
        Script83();
        break;
      case "5x5PqEBVVhI":
        Script84();
        break;
      case "5miGcsPf2GB":
        Script85();
        break;
      case "5cbiKhTaOMI":
        Script86();
        break;
      case "6OQO2fv98tR":
        Script87();
        break;
      case "6FKhkPYliLD":
        Script88();
        break;
      case "5vrBzNPVnTF":
        Script89();
        break;
      case "6POQH2ay7SD":
        Script90();
        break;
      case "69M30p17Hf3":
        Script91();
        break;
      case "5vb6E9Kk9m1":
        Script92();
        break;
      case "5esPpCtqD79":
        Script93();
        break;
      case "6OqsX0MwQSt":
        Script94();
        break;
      case "610OMJAdPot":
        Script95();
        break;
      case "6R3wlbkNMsu":
        Script96();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
window.Script1 = function()
{
  player.once(() => {
const target = object('6YvyQvYDvrp');
const duration = 1500;
const easing = 'ease-out';
const id = '5k4Mli6EtWI';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script2 = function()
{
  player.once(() => {
const target = object('6YvyQvYDvrp');
const duration = 1500;
const easing = 'ease-out';
const id = '5k4Mli6EtWI';
const pulseAmount = 0.07;
const delay = 28000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script3 = function()
{
  player.once(() => {
const target = object('6IDRwPzv7x9');
const duration = 1500;
const easing = 'ease-out';
const id = '6JheYHIpH0o';
const pulseAmount = 0.1;
const delay = 62000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script4 = function()
{
  player.once(() => {
const target = object('65rT74EsCbr');
const duration = 1500;
const easing = 'ease-out';
const id = '5qmop5hE86h';
const pulseAmount = 0.1;
const delay = 68000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script5 = function()
{
  player.once(() => {
const target = object('5yuseDTr3tj');
const duration = 750;
const easing = 'ease-out';
const id = '6dXvbVLHGa9';
const pulseAmount = 0.07;
const delay = 74000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script6 = function()
{
  player.once(() => {
const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 86750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script7 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script8 = function()
{
  player.once(() => {
const target = object('612AmuW8HrE');
const duration = 1500;
const easing = 'ease-out';
const id = '6J2frrhpfOf';
const pulseAmount = 0.07;
const delay = 91500;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script9 = function()
{
  player.once(() => {
const target = object('6GaRnMfcvNB');
const duration = 2000;
const easing = 'ease-out';
const id = '6XoypW8FIyl';
const pulseAmount = 0.07;
const delay = 97146;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script10 = function()
{
  player.once(() => {
const target = object('6MHj7FdyhGV');
const duration = 1500;
const easing = 'ease-out';
const id = '5t2XwWG7Sup';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script11 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script12 = function()
{
  const target = object('5mn4o9MTjTy');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script13 = function()
{
  const target = object('6GvUJYwV5Ik');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script14 = function()
{
  const target = object('5dVGn2xmJLX');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script15 = function()
{
  player.once(() => {
const target = object('5WSlUXHc5eC');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script16 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script17 = function()
{
  player.once(() => {
const target = object('67wwYmfaUIC');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script18 = function()
{
  player.once(() => {
const target = object('5YriBLHF1fi');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script19 = function()
{
  player.once(() => {
const target = object('5zdcqNqWbI1');
const duration = 1500;
const easing = 'ease-out';
const id = '61HuSZSRE9g';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script20 = function()
{
  player.once(() => {
const target = object('5vY5bfvRaMq');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script21 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script22 = function()
{
  const target = object('5vY5bfvRaMq');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script23 = function()
{
  player.once(() => {
const target = object('5tI9djaDgyI');
const duration = 750;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script24 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script25 = function()
{
  player.once(() => {
const target = object('6lb7uUBvwkF');
const duration = 750;
const easing = 'ease-out';
const id = '6GPtK9YZLpx';
const pulseAmount = 0.07;
const delay = 26750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script26 = function()
{
  player.once(() => {
const target = object('5mBMOghnR2Y');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 26750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script27 = function()
{
  player.once(() => {
const target = object('5nkgHR4pwAX');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script28 = function()
{
  player.once(() => {
const target = object('5rOza2qRZKX');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script29 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script30 = function()
{
  const target = object('5vPlgC0AGV1');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script31 = function()
{
  const target = object('5qY5vwAWuIe');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script32 = function()
{
  const target = object('5rOza2qRZKX');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script33 = function()
{
  player.once(() => {
const target = object('6iJnB6Uni16');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script34 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script35 = function()
{
  player.once(() => {
const target = object('6kHdCmk5us9');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script36 = function()
{
  player.once(() => {
const target = object('6ZncsDaD43B');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script37 = function()
{
  player.once(() => {
const target = object('6i17k43pT4C');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script38 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script39 = function()
{
  const target = object('6i17k43pT4C');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script40 = function()
{
  player.once(() => {
const target = object('6bLCw6aAMkL');
const duration = 1250;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script41 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script42 = function()
{
  player.once(() => {
const target = object('5bp0trzm1xF');
const duration = 750;
const easing = 'ease-out';
const id = '6GPtK9YZLpx';
const pulseAmount = 0.07;
const delay = 24750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script43 = function()
{
  player.once(() => {
const target = object('5rGElrxsMrA');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 24750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script44 = function()
{
  player.once(() => {
const target = object('6o2UIBBk1MT');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script45 = function()
{
  player.once(() => {
const target = object('6D7N9ivrEjv');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script46 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script47 = function()
{
  const target = object('5ZptlL8dg2O');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script48 = function()
{
  const target = object('6XKvL9sMu4u');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script49 = function()
{
  const target = object('6D7N9ivrEjv');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script50 = function()
{
  player.once(() => {
const target = object('6WcORRrIUCE');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script51 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script52 = function()
{
  player.once(() => {
const target = object('5i0VB3ZKJtI');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script53 = function()
{
  player.once(() => {
const target = object('6qwxFiOECT3');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script54 = function()
{
  player.once(() => {
const target = object('6cx0YN6AkgS');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script55 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script56 = function()
{
  const target = object('6cx0YN6AkgS');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script57 = function()
{
  player.once(() => {
const target = object('6AGg0MaqIzb');
const duration = 750;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script58 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script59 = function()
{
  player.once(() => {
const target = object('6B0gEtFYuQZ');
const duration = 750;
const easing = 'ease-out';
const id = '6GPtK9YZLpx';
const pulseAmount = 0.07;
const delay = 30000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script60 = function()
{
  player.once(() => {
const target = object('6jh8Uxkjqsm');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 30000;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script61 = function()
{
  player.once(() => {
const target = object('6bkgZ5iqYn4');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script62 = function()
{
  player.once(() => {
const target = object('6aj1gojQYCO');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script63 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script64 = function()
{
  const target = object('6LAa4FcPBgM');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script65 = function()
{
  const target = object('5zKj5neZu5a');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script66 = function()
{
  const target = object('6aj1gojQYCO');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script67 = function()
{
  player.once(() => {
const target = object('6V3lg47BoB4');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script68 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script69 = function()
{
  player.once(() => {
const target = object('5zS3Hz2X5ps');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script70 = function()
{
  player.once(() => {
const target = object('5e1MmTLQ3vD');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script71 = function()
{
  player.once(() => {
const target = object('6huGCVuryCd');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script72 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script73 = function()
{
  const target = object('6huGCVuryCd');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script74 = function()
{
  player.once(() => {
const target = object('6a9P9WTzEii');
const duration = 750;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script75 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script76 = function()
{
  player.once(() => {
const target = object('6J7TvXZptO1');
const duration = 750;
const easing = 'ease-out';
const id = '6GPtK9YZLpx';
const pulseAmount = 0.07;
const delay = 28750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script77 = function()
{
  player.once(() => {
const target = object('5YUPDgi2W8i');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 28750;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script78 = function()
{
  player.once(() => {
const target = object('5Yjtjo085Db');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script79 = function()
{
  player.once(() => {
const target = object('64B7E5njLVZ');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script80 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script81 = function()
{
  const target = object('6Bd0XeQKLuw');
const duration = 1500;
const easing = 'ease-out';
const id = '6Qq9xKZlQye';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script82 = function()
{
  const target = object('6YjQFEBD2fe');
const duration = 1500;
const easing = 'ease-out';
const id = '6XFnVdrH2L4';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script83 = function()
{
  const target = object('64B7E5njLVZ');
const duration = 1500;
const easing = 'ease-out';
const id = '6E0WQnvHUSo';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script84 = function()
{
  player.once(() => {
const target = object('5Yp3cVVXtqB');
const duration = 750;
const easing = 'ease-out';
const id = '6GwQSghFvtz';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script85 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script86 = function()
{
  player.once(() => {
const target = object('624N1sYtpe7');
const duration = 750;
const easing = 'ease-out';
const id = '5YcdZK8jCYO';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script87 = function()
{
  player.once(() => {
const target = object('5wMZhjTbNed');
const duration = 750;
const easing = 'ease-out';
const id = '64cQmKbNJBg';
const pulseAmount = 0.07;
const delay = 12250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script88 = function()
{
  player.once(() => {
const target = object('6YtcvhMWYs8');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script89 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script90 = function()
{
  const target = object('6YtcvhMWYs8');
const duration = 1500;
const easing = 'ease-out';
const id = '6YRthpLX574';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script91 = function()
{
  player.once(() => {
const target = object('5z3FPSoiqXD');
const duration = 750;
const easing = 'ease-out';
const id = '6CzcQ1CHkyA';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script92 = function()
{
  const target = object('5wR1MnIcXt2');
const duration = 750;
const easing = 'ease-out';
const id = '5kgTiEFowZ5';
const pulseAmount = 0.07;
const delay = 3625;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script93 = function()
{
  player.once(() => {
const target = object('60ak6f8rw94');
const duration = 750;
const easing = 'ease-out';
const id = '6GPtK9YZLpx';
const pulseAmount = 0.07;
const delay = 26250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script94 = function()
{
  player.once(() => {
const target = object('5sEmw8bCArL');
const duration = 750;
const easing = 'ease-out';
const id = '5YHkvCdwho9';
const pulseAmount = 0.07;
const delay = 26250;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script95 = function()
{
  player.once(() => {
const target = object('6XgeS6RjmMG');
const duration = 750;
const easing = 'ease-out';
const id = '6UtBCRKB5Hv';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

};
